﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VOTE
{
    class Valasztas
    {
        public int ker;
        public int szavaz;
        public string vnev;
        public string knev;
        public string teljesnev;
        public string part;

        public Valasztas(string sor)
        {
            string[] temp = sor.Split(' ');
            ker = Convert.ToInt32(temp[0]);
            szavaz= Convert.ToInt32(temp[1]);
            vnev = temp[2];
            knev = temp[3];
            teljesnev = temp[2]+" "+temp[3];
            part = temp[4].Replace("-","Független jelölt");
            
        }
        

       
    }
    internal class Program
    {
        static List<Valasztas> lista= new List<Valasztas>();
        static void beolvas()
        {
            StreamReader sr = new StreamReader("szavazatok.txt");
            while (!sr.EndOfStream)
            {
                Valasztas uj = new Valasztas(sr.ReadLine());
                lista.Add(uj);
                

            }
            sr.Close();
        }
        static void kiir()
        {
            foreach (var item in lista)
            {
                Console.WriteLine($"{item.teljesnev} {item.part}");

            }


        }
        static void f2()
        {
            Console.WriteLine("2.feladat");
            Console.WriteLine($"A helyhatósági választáson {lista.Count()} képviselőjelölt indult");
        }
        static void f3()
        {
            Console.WriteLine("3.feladat");
            int darab = 0;
            Console.WriteLine("Vezetékneve: ");
            string vezetekn = Console.ReadLine();
            Console.WriteLine("Keresztneve: ");
            string keresztn = Console.ReadLine();
            foreach (var item in lista)
            {
                if (item.vnev==vezetekn && item.knev==keresztn)
                {
                    darab++;
                    Console.WriteLine($"{item.teljesnev} nevű jelölt {item.szavaz} kapott");

                }
                

            }
            if (darab==0)
            {
                Console.WriteLine($"Ilyen nevű képviselőjelölt nem szerepel a nyilvántartásban!");

            }
        }
        static void f4()
        {
            Console.WriteLine("4.feladat");
            Console.WriteLine($"A választáson {lista.Sum(x=>x.szavaz)} állampolgár, a jogosultak {Math.Round(((double)lista.Sum(x => x.szavaz)/12345)*100,2)}%-a vett részt");
        }
        static void f5()
        {
            Console.WriteLine("5.feladat");
            int ossz = lista.Sum(x => x.szavaz);
            Console.WriteLine(ossz);
            Dictionary<string,double> stat= new Dictionary<string,double>();
            foreach (var item in lista)
            {
                string kulcs = item.part;
                if (!stat.ContainsKey(kulcs))
                {
                    stat.Add(kulcs, 1);
                   


                }
                stat[kulcs]+= Math.Round(((double)item.szavaz / ossz) * 100, 2);

            }
            


            

            foreach (var item in stat)
            {
                Console.WriteLine($"{item.Value} {item.Key}");

            }

        }
        static void f6()
        {
            Console.WriteLine("6.feladat");
            int legtobb = lista.Select(x=>x.szavaz).Max();
            foreach (var item in lista)
            {
                if (item.szavaz==legtobb)
                {
                    Console.WriteLine($"{item.szavaz} számmal, {item.teljesnev}-re/ra szavaztak a legtöbben, {item.part} a pártja neve");

                }

            }
        }
        static void f7()
        {
            Console.WriteLine("7.feladat");
            StreamWriter sr = new StreamWriter("kepviselo.txt");


        }
        static void Main(string[] args)
        {
            beolvas();
            //kiir();
            f2();
            //f3();
            f4();
            f5();
            //f6();


            Console.ReadKey();
        }
    }
}
